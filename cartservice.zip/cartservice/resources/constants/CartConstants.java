package com.albertsons.cartservice.resources.constants;

public class CartConstants {
}
