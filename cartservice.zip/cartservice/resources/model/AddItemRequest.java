package com.albertsons.cartservice.resources.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AddItemRequest {

    private String Id;
    private String item_id;
    private String upc_type;
    private String scan_code;
    private Double added_time_stamp;
    private Double last_updated_time_stamp;
    private int quantity;
    private boolean bag_item;
    private boolean weight_item;
}
