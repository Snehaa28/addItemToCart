package com.albertsons.cartservice.resources.model;

import lombok.*;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.stereotype.Component;

@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
@Document(collection = "Items")
@ToString
@Component
@Builder
public class Item {

    @Id
    private String Id;
    private String item_id;
    private Double added_time_stamp;
    private Double last_updated_time_stamp;
    private String upc_type;
    private String scan_code;
    private int quantity;
    private String status;
    private Boolean weight_item;
    private Boolean bag_item;
}
