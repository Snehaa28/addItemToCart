package com.albertsons.cartservice.resources.model;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.ArrayList;


@Getter
@Setter
@Document
@ToString
public class Cart {

    @Id
    private String Id;
    private Double time_stamp;
    private String guid;
    private String store_id;
    ArrayList<Item> items;
    private int _v;
    private String order_id;
    private String transaction_status;
    private String terminal_number;
    private String transaction_id;
}
