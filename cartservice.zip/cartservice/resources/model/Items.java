package com.albertsons.cartservice.resources.model;

import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;

@Getter
@Setter
public class Items {
    ArrayList<Item> items = new ArrayList<>();
}
