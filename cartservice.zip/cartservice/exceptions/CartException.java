package com.albertsons.cartservice.exceptions;

public class CartException {
}
