package com.albertsons.cartservice.constants;

public class CartConstants {

    public static final int CART_LIMIT = 15;
    public static final int ITEM_LIMIT = 50;

    public static final String MESSAGE_GENERIC1 = "Item already Exists";
    public static final String MESSAGE_GENERIC2 = "Something went wrong. Mongo DB issue";
    public static final String MESSAGE_GENERIC3 = "Item Successfully Found";
}
