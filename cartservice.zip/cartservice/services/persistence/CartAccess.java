package com.albertsons.cartservice.services.persistence;

public class CartAccess {
}
