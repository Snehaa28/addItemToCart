package com.albertsons.cartservice.services.persistence;

public interface ICartAccess {
}
