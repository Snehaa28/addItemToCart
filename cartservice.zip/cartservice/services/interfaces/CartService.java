package com.albertsons.cartservice.services.interfaces;

import com.albertsons.cartservice.resources.model.AddItemRequest;
import com.albertsons.cartservice.resources.model.AddItemResponse;

public interface CartService {
    AddItemResponse addItemToCart(String storeId, String guid, AddItemRequest items);
}
