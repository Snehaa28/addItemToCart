package com.albertsons.cartservice.services.implementation;

import com.albertsons.cartservice.persistence.CartRepo;
import com.albertsons.cartservice.resources.model.AddItemRequest;
import com.albertsons.cartservice.resources.model.AddItemResponse;
import com.albertsons.cartservice.resources.model.Cart;
import com.albertsons.cartservice.resources.model.Item;
import com.albertsons.cartservice.services.interfaces.CartService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class CartServiceImpl implements CartService {
    @Autowired
    CartRepo cartRepo;

    @Override
    public AddItemResponse addItemToCart(String storeId, String guid, AddItemRequest request) {
        Optional<Cart> cart = cartRepo.findByguid(guid);
        System.out.println("cart data  " + cart);
        AddItemResponse response = null;
        if (cart.isPresent()) {
            Cart cartData = cart.get();

            ArrayList<Item> itemsList = cartData.getItems();
            System.out.println("total items in the cart = " + itemsList.size());
            List<Item> duplicateItemsList = itemsList.stream()
                    .filter(item -> item.getItem_id().equals(request.getItem_id()) && item.getUpc_type().equals(request.getUpc_type()) && item.getScan_code().equals(request.getScan_code())).collect(Collectors.toCollection(ArrayList::new));
            if (duplicateItemsList.isEmpty()) {
                Item newItem = new Item();
                newItem.setItem_id(request.getItem_id());
                newItem.setAdded_time_stamp((double) new Date().getTime());
                newItem.setLast_updated_time_stamp((double) new Date().getTime());
                newItem.setUpc_type(request.getUpc_type());
                newItem.setScan_code(request.getScan_code());
                newItem.setQuantity(request.getQuantity());
                newItem.setStatus("Active");
                newItem.setBag_item(false);
                newItem.setWeight_item(false);
                itemsList.add(newItem);
                cartData.setItems(itemsList);
                response = addedResponse();
            } else {
                duplicateItemsList.forEach(updateItem -> updateItem.setLast_updated_time_stamp((double) new Date().getTime()));
                cartData.setItems((ArrayList<Item>) duplicateItemsList);
                response = updateResponse();
            }
            System.out.println("print cart data " + cartData);
//            cartRepo.save(cartData);
        }
        return response;
    }

    private AddItemResponse updateResponse() {
        AddItemResponse response = new AddItemResponse();
        response.setAck("1");
        response.setCode("2000");
        response.setVendor("scan_go");
        response.setMessage("Successfully updated item");
        response.setCategory("generic_response");
        return response;
    }

    private AddItemResponse addedResponse() {
        AddItemResponse response = new AddItemResponse();
        response.setAck("1");
        response.setCode("2000");
        response.setVendor("scan_go");
        response.setMessage("Item added to the cart successfully");
        response.setCategory("generic_response");
        return response;
    }
}