package com.albertsons.cartservice.controller;

import com.albertsons.cartservice.resources.model.AddItemRequest;
import com.albertsons.cartservice.resources.model.AddItemResponse;
import com.albertsons.cartservice.services.implementation.CartServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.*;

@RestController
@Component
@RequestMapping("/api")
public class CartController {

    @Autowired
    CartServiceImpl cartServiceImpl;

    @PutMapping("/addItemToCart")
    public ResponseEntity<AddItemResponse> addItemToCart(@RequestHeader("storeId") String storeId,
                                                         @RequestHeader("GUID") String guid,
                                                         @RequestBody AddItemRequest request) {
        AddItemResponse response = cartServiceImpl.addItemToCart(storeId, guid, request);
        return new ResponseEntity<AddItemResponse>(response, HttpStatus.OK);
    }
}
